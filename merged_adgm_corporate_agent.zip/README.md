
# ADGM Corporate Agent (Prototype)

A working prototype of the ADGM Corporate Agent described in your Task.pdf and Data Sources.pdf.
This project is a minimal, runnable implementation with a Gradio UI, `.docx` parsing, checklist verification (using the provided Data Sources), inline comment insertion, and a RAG-ready skeleton for ADGM references.

## What is included
- `app.py` — main Gradio app (upload `.docx`, run review, download reviewed `.docx`)
- `docx_processor.py` — functions to parse `.docx`, detect doc types, insert comments and highlights
- `rag.py` — skeleton for RAG (indexing ADGM reference files & querying). Plug in your LLM/embeddings provider.
- `adgm_checklist.json` — checklist derived from Data Sources.pdf
- `sample_input.docx` — small example input doc (created programmatically)
- `sample_reviewed.docx` — example output with comments inserted
- `requirements.txt` — Python dependencies
- `README.md` — this file

## How to run (local)
1. Create a Python 3.10+ virtual environment
2. `pip install -r requirements.txt`
3. Set environment variables for your LLM provider (e.g., OPENAI_API_KEY) if you will enable RAG
4. `python app.py`
5. Open the Gradio link shown in the terminal and upload `.docx` files to test.

## Notes
- The RAG implementation is a template using `sentence-transformers` and `faiss` and expects you to provide ADGM reference documents (PDFs/DOCs) in `./references/` to index them.
- Inline commenting in Word is implemented with `python-docx` by inserting bracketed comment markers next to flagged paragraphs (Word's real comment object model isn't supported directly by python-docx). For real Word comment objects, consider `docxcompose` or `mammoth` or using `python-docx`'s low-level XML manipulation.

## License
MIT


## Enabling RAG with OpenAI

To enable RAG + LLM generation, set your OpenAI API key in the environment:

```bash
export OPENAI_API_KEY=sk-...  # Linux/Mac
setx OPENAI_API_KEY "sk-..." # Windows
```

You can also set the desired OpenAI model by setting OPENAI_MODEL environment variable (default: gpt-4o-mini).

After setting the key, restart the app and use the 'Ask with RAG' box to query ADGM references.
