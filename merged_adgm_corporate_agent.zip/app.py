
import gradio as gr
from docx_processor import extract_text_from_docx, detect_document_types, check_missing_documents, detect_red_flags, insert_comments_into_docx, load_checklist
from pathlib import Path
import uuid, json, os
from rag import SimpleRAG

UPLOAD_DIR = Path('./uploads')
UPLOAD_DIR.mkdir(exist_ok=True)
REVIEW_DIR = Path('./reviews')
REVIEW_DIR.mkdir(exist_ok=True)

# Initialize RAG index (load if exists)
rag = SimpleRAG()
try:
    rag.load_index()
except Exception as e:
    print('RAG load failed or index not present:', e)

def review_docx(file_obj):
    uid = str(uuid.uuid4())[:8]
    src = UPLOAD_DIR / f"input_{uid}.docx"
    with open(src,'wb') as f:
        f.write(file_obj.read())

    text = extract_text_from_docx(str(src))
    detected = detect_document_types(text, load_checklist())
    check = check_missing_documents(detected)
    issues = detect_red_flags(text)
    reviewed_path = REVIEW_DIR / f"reviewed_{uid}.docx"
    insert_comments_into_docx(str(src), str(reviewed_path), issues)

    output = {
        'process': 'Company Incorporation (detected)',
        'documents_detected': detected,
        'required_documents': check['required_documents'],
        'uploaded_count': check['uploaded_count'],
        'missing_documents': check['missing_documents'],
        'issues_found': issues
    }
    return reviewed_path, json.dumps(output, indent=2)

def rag_query(question):
    if not question or question.strip() == '':
        return 'Please enter a question.'
    resp = rag.answer_with_rag(question, k=3)
    return json.dumps(resp, indent=2, ensure_ascii=False)

with gr.Blocks() as demo:
    gr.Markdown('# ADGM Corporate Agent — Prototype with RAG (OpenAI)')
    with gr.Row():
        with gr.Column():
            uploader = gr.File(label='Upload a .docx file (single)', file_types=['.docx'])
            review_btn = gr.Button('Run Review')
            out_file = gr.File(label='Download reviewed .docx')
            out_json = gr.Textbox(label='JSON Summary', lines=12)
        with gr.Column():
            gr.Markdown('### Ask ADGM (RAG powered)')
            question = gr.Textbox(label='Question about ADGM or your documents', lines=4)
            ask_btn = gr.Button('Ask with RAG')
            rag_out = gr.Textbox(label='RAG Answer (LLM)', lines=12)

    def run(file):
        if file is None:
            return None, '{"error":"no file uploaded"}'
        reviewed, summary = review_docx(file)
        return reviewed, summary

    review_btn.click(fn=run, inputs=uploader, outputs=[out_file, out_json])
    ask_btn.click(fn=rag_query, inputs=question, outputs=rag_out)

if __name__ == '__main__':
    demo.launch()
