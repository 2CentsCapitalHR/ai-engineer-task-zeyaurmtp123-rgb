
from docx import Document
from typing import List, Dict
import re
import json

def extract_text_from_docx(path: str) -> str:
    doc = Document(path)
    texts = [p.text for p in doc.paragraphs if p.text and p.text.strip()!='']
    return '\n'.join(texts)

def detect_document_types(text: str, checklist: Dict) -> List[str]:
    detected = []
    # naive keyword-based detection
    if 'article' in text.lower() or 'articles of association' in text.lower():
        detected.append('Articles of Association')
    if 'memorandum' in text.lower() or 'memorandum of association' in text.lower():
        detected.append('Memorandum of Association')
    if 'ubo' in text.lower() or 'ultimate beneficial owner' in text.lower():
        detected.append('UBO Declaration Form')
    if 'register of members' in text.lower() or 'register of directors' in text.lower():
        detected.append('Register of Members and Directors')
    if 'resolution' in text.lower() and 'incorporate' in text.lower():
        detected.append('Resolution for Incorporation')
    return detected

def load_checklist(path='adgm_checklist.json'):
    with open(path,'r') as f:
        return json.load(f)

def check_missing_documents(uploaded_types: List[str], checklist_name='Company_Incorporation_Private_Limited'):
    checklist = load_checklist()
    required = checklist[checklist_name]['required_documents']
    missing = [d for d in required if d not in uploaded_types]
    return {
        'required_documents': required,
        'uploaded_count': len(uploaded_types),
        'missing_documents': missing
    }

def detect_red_flags(text: str) -> List[Dict]:
    issues = []
    # example checks
    if 'federal court' in text.lower() or 'u.a.e. federal' in text.lower():
        issues.append({
            'section': 'Jurisdiction Clause',
            'issue': 'References UAE Federal Courts instead of ADGM',
            'severity': 'High',
            'suggestion': 'Update jurisdiction to ADGM Courts per ADGM Companies Regulations.'
        })
    # detect missing signatory block
    if re.search(r'signature', text, re.IGNORECASE) is None:
        issues.append({
            'section': 'Signatories',
            'issue': 'No signature block found',
            'severity': 'Medium',
            'suggestion': 'Add signatory lines with names, titles and dates.'
        })
    return issues

def insert_comments_into_docx(src_path: str, dest_path: str, issues: List[Dict]):
    doc = Document(src_path)
    for p in doc.paragraphs:
        for issue in issues:
            # naive match: if any keyword from suggestion in paragraph, tag it
            keywords = ['jurisdiction','signat','ubo','register of members']
            for kw in keywords:
                if kw in p.text.lower():
                    # append bracketed comment (python-docx doesn't support Word comments natively)
                    p.add_run('  [REVIEW NOTE: {}]'.format(issue['issue']))
    doc.save(dest_path)
