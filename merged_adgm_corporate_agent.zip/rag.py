
import os
import pickle
from typing import List, Tuple
from sentence_transformers import SentenceTransformer
import faiss
from pathlib import Path
import openai
import textwrap

OPENAI_MODEL = os.environ.get('OPENAI_MODEL', 'gpt-4o-mini')  # change if needed
OPENAI_API_KEY = os.environ.get('OPENAI_API_KEY')

if OPENAI_API_KEY:
    openai.api_key = OPENAI_API_KEY

class SimpleRAG:
    def __init__(self, model_name='all-MiniLM-L6-v2', index_path='./references_index.faiss'):
        self.model = SentenceTransformer(model_name)
        self.index_path = index_path
        self.index = None
        self.docs = []

    def index_documents(self, texts: List[str]):
        embs = self.model.encode(texts, convert_to_numpy=True, show_progress_bar=True)
        d = embs.shape[1]
        index = faiss.IndexFlatL2(d)
        index.add(embs)
        self.index = index
        self.docs = texts
        faiss.write_index(index, self.index_path)
        with open(self.index_path + '.meta', 'wb') as f:
            pickle.dump(self.docs, f)

    def load_index(self):
        meta = Path(self.index_path + '.meta')
        if Path(self.index_path).exists() and meta.exists():
            self.index = faiss.read_index(self.index_path)
            with open(self.index_path + '.meta','rb') as f:
                self.docs = pickle.load(f)

    def query(self, text: str, k=3) -> List[Tuple[str,float]]:
        if self.index is None:
            raise RuntimeError('Index not loaded. Call load_index() or index_documents() first.')
        q = self.model.encode([text], convert_to_numpy=True)
        D, I = self.index.search(q, k)
        results = []
        for dist, idx in zip(D[0], I[0]):
            results.append((self.docs[idx], float(dist)))
        return results

    def answer_with_rag(self, question: str, k=3) -> dict:
        """Retrieve top-k passages and ask the LLM to answer using them.
        Returns a dict with 'answer' and 'sources'"""
        # 1) retrieve
        retrieved = []
        if self.index is not None:
            retrieved = self.query(question, k=k)
        # 2) build context
        context = ''
        sources = []
        for i, (text, dist) in enumerate(retrieved):
            context += f"PASSAGE {i+1}:\n{text}\n\n"
            sources.append({'id': i+1, 'distance': dist})

        # 3) build prompt
        system_msg = (
            "You are ADGM Corporate Agent assistant. Use the provided ADGM passages to answer the question. "
            "If the passages do not contain an answer, say 'No direct match found in provided ADGM references.'"
        )
        user_prompt = textwrap.dedent(f"""
        Question: {question}

        ADGM Passages:\n{context}

        Please: \n1) Provide a concise answer (2-6 sentences).\n2) Explain which passage(s) you used (by PASSAGE number).\n3) If you provide a suggestion for document edits, include the exact clause text to replace or insert.\n        """)

        # 4) call OpenAI Chat Completion (if API key present)
        if not openai.api_key:
            return {'answer': 'OPENAI_API_KEY not set. Cannot call LLM. Provide OPENAI_API_KEY env var.', 'sources': sources}

        try:
            resp = openai.ChatCompletion.create(
                model=OPENAI_MODEL,
                messages=[
                    {"role": "system", "content": system_msg},
                    {"role": "user", "content": user_prompt}
                ],
                temperature=0.0,
                max_tokens=800
            )
            text = resp['choices'][0]['message']['content'].strip()
        except Exception as e:
            text = f'LLM call failed: {e}'

        return {'answer': text, 'sources': sources}
